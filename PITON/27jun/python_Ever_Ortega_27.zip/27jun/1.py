arr = list(
    [
        "Matemáticas",
        "Física",
        "Química",
        "Historia",
        "Lengua y Literatura Castellana",
        "Educación Vial",
        "Laboratorio Software",
    ]
)
print("Las materias que tenemos:")
for l in arr:
    print(l)
