arr = [50, 75, 46, 22, 80, 65, 8]
arr.sort()
print("El menor valor es: ", arr[0])
print("El mayor valor es: ", arr[-1])
