def saludo(nombre):
    print(f"¡Hola {nombre}!")


nom = input("Ingrese un nombre: ")
saludo((nom))
