def hola_amiga():
    print("¡Hola amiga!")


# main function
hola_amiga()
