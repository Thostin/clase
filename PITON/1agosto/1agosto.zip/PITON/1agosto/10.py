def xd(n, m):
    print(f"{n} entre {m} da in cociente {int(n / m)} y un resto {n % m}")


n = int(input("Ingrese un entero positivo: "))
m = int(input("Ingrese otro entero positivo: "))
xd(n, m)
